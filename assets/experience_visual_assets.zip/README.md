# Experience Section 视觉素材

透明 PNG 均已紧贴有效内容裁切，没有大面积透明留白。

- `brand_compass_star.png`：页头左侧品牌星标。
- `metal_rivet.png`：卡片四角金属铆钉，可复用并用 CSS 调整尺寸。
- `lime_sparkle.png`：荧光绿色星芒装饰，可缩放复用。
- `orbit_doodle.png`：左下角轨道手绘线装饰。
- `masking_tape_corner.png`：卡片右上角半透明胶带。

建议：
- 卡片正文、标题、日期、右侧数据、标签、时间轴和边框全部使用 HTML/CSS。
- 点阵、细线、圆点、十字和简单星芒优先使用 CSS 或 SVG。
- 不建议把整块经历卡片做成图片；会损失清晰度、响应式能力、可访问性与后续维护能力。
